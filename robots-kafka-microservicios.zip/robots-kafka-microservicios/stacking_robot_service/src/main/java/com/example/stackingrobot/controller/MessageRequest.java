package com.example.stackingrobot.controller;

public class MessageRequest {
    private String message;

    // Getters y Setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
