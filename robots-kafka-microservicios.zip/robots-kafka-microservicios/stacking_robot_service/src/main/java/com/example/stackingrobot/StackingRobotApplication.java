package com.example.stackingrobot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StackingRobotApplication {
    public static void main(String[] args) {
    	 SpringApplication.run(StackingRobotApplication.class, args);
    }
}

