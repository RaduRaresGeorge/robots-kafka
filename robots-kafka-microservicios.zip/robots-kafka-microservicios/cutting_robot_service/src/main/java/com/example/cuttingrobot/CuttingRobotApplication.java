package com.example.cuttingrobot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CuttingRobotApplication {

    public static void main(String[] args) {
        SpringApplication.run(CuttingRobotApplication.class, args);
    }
}
