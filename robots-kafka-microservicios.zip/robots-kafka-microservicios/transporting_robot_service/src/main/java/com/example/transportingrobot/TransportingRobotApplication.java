package com.example.transportingrobot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransportingRobotApplication {
    public static void main(String[] args) {
    	 SpringApplication.run(TransportingRobotApplication.class, args);
    }
}
